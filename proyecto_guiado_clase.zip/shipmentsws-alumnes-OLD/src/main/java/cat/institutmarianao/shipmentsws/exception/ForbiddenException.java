package cat.institutmarianao.shipmentsws.exception;

public class ForbiddenException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}