package cat.institutmarianao.shipmentsws.services.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import cat.institutmarianao.shipmentsws.model.Shipment;
import cat.institutmarianao.shipmentsws.model.Shipment.Category;
import cat.institutmarianao.shipmentsws.model.Shipment.Status;
import cat.institutmarianao.shipmentsws.repositories.ShipmentRepository;
import cat.institutmarianao.shipmentsws.services.ShipmentService;
import cat.institutmarianao.shipmentsws.specifications.ShipmentWithStatus;
import cat.institutmarianao.shipmentsws.specifications.ShipmentWithCategory;

@Service
public class ShipmentServiceImpl implements ShipmentService{

	@Autowired
	private ShipmentRepository shipmentRepository;
	
	@Override
	public List<Shipment> findAll(Status status, String receivedBy, String courierAssigned, Category category, Date from, Date to) {
		Specification<Shipment> spec = Specification.where(new ShipmentWithStatus(status)).and(new ShipmentWithCategory(category));
		return shipmentRepository.findAll(spec);
	}

	@Override
	public Shipment findById(Long id) {
		Optional<Shipment> shipment = shipmentRepository.findById(id);
		if (shipment.isEmpty()) {
			return null;
		}
		return shipment.get();
	}

}
