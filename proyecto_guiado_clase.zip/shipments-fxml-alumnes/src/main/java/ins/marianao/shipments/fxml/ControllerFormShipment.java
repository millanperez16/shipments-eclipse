package ins.marianao.shipments.fxml;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.exception.ExceptionUtils;

import cat.institutmarianao.shipmentsws.model.Action;
import cat.institutmarianao.shipmentsws.model.Action.Type;
import cat.institutmarianao.shipmentsws.model.Address;
import cat.institutmarianao.shipmentsws.model.Shipment;
import cat.institutmarianao.shipmentsws.model.Shipment.Category;
import cat.institutmarianao.shipmentsws.model.User;
import cat.institutmarianao.shipmentsws.model.Reception;
import ins.marianao.shipments.fxml.manager.ResourceManager;
import ins.marianao.shipments.fxml.services.ServiceSaveShipment;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.GridPane;
import javafx.util.Pair;
import javafx.util.StringConverter;
import javafx.util.converter.FloatStringConverter;

public class ControllerFormShipment implements Initializable, ChangeListener<Pair<String, String>> {

	@FXML
	private ComboBox<Pair<String, String>> cmbCategory;

	@FXML
	private TextField txtHeight;
	@FXML
	private TextField txtWeight;
	@FXML
	private TextField txtWidth;
	@FXML
	private TextField txtLength;

	@FXML
	private CheckBox express;

	@FXML
	private CheckBox fragile;

	@FXML
	private Button btnSender;
	@FXML
	private Button btnRecipient;

	@FXML
	private TextArea txtareaNote;

	@FXML
	private Button btnSave;

	private boolean edicio;
	private Address senderAddress = null;
	private Address recipientAddress = null;

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle resource) {
		this.edicio = false;

		// this.lblUsuari.setText("\u2386");
		// this.lblNom.setText("\u1F604");
		// this.lblExtensio.setText("\u2706");

		List<Pair<String, String>> categories = Stream.of(Shipment.Category.values())
				.map(new Function<Category, Pair<String, String>>() {
					@Override
					public Pair<String, String> apply(Category t) {
						String key = t.name();
						return new Pair<String, String>(key, resource.getString("text.Category." + key));
					}

				}).collect(Collectors.toList());

		this.cmbCategory.setItems(FXCollections.observableArrayList(categories));
		this.cmbCategory.setConverter(Formatters.getStringPairConverter("Category"));
		
		StringConverter<Float> floatConverter = new FloatStringConverter();
		
		this.txtHeight.setTextFormatter(new TextFormatter<Float>(floatConverter));
		this.txtWeight.setTextFormatter(new TextFormatter<Float>(floatConverter));
		this.txtWidth.setTextFormatter(new TextFormatter<Float>(floatConverter));
		this.txtLength.setTextFormatter(new TextFormatter<Float>(floatConverter));

		this.express.setSelected(false);
		this.fragile.setSelected(false);

		btnSender.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				senderAddress = createAddressDialog();
			}
		});

		btnRecipient.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				recipientAddress = createAddressDialog();
			}
		});
	}

	@Override
	public void changed(ObservableValue<? extends Pair<String, String>> observable, Pair<String, String> oldValue,
			Pair<String, String> newValue) {

	}

	@FXML
	public void saveShipmentClick(ActionEvent event) {
		try {
			Pair<String, String> categories = this.cmbCategory.getValue();

			float numHeight = (float) this.txtHeight.getTextFormatter().getValue();
			float numWeight = (float) this.txtWeight.getTextFormatter().getValue();
			float numWidth = (float) this.txtWidth.getTextFormatter().getValue();
			float numLength = (float) this.txtLength.getTextFormatter().getValue();
			String strNote = this.txtareaNote.getText();

			boolean expresschk = express.isSelected();
			boolean fragilechk = fragile.isSelected();

			// crear objeto shipment y llamar a saveShipment
			Shipment shipment = new Shipment();
			shipment.setCategory(Category.valueOf(categories.getKey()));
			shipment.setRecipient(recipientAddress);
			shipment.setSender(senderAddress);
			shipment.setHeight(numHeight);
			shipment.setWeight(numWeight);
			shipment.setWidth(numWidth);
			shipment.setLength(numLength);
			shipment.setExpress(expresschk);
			shipment.setFragile(fragilechk);
			shipment.setNote(strNote);
			
			if (shipment.getTracking() == null) {
				List<Action> actionsShipment = new ArrayList<>();
				Reception reception = new Reception();
				actionsShipment.add(reception);
				User performer = ResourceManager.getInstance().getCurrentUser();
				reception.setPerformer(performer);
				reception.setType(Type.RECEPTION);
				shipment.setTracking(actionsShipment);
			}

			saveShipment(shipment, true);

		} catch (Exception e) {
			ControllerMenu.showError(e.getMessage(), e.getMessage(), ExceptionUtils.getStackTrace(e));
		}
	}

	@FXML
	private Address createAddressDialog() {

		Dialog<List<String>> dialog = new Dialog<>();
		dialog.setTitle("New Address");

		ButtonType saveButtonType = new ButtonType("Save", ButtonData.OK_DONE);
		dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

		GridPane grid = new GridPane();
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(20, 150, 10, 10));

		TextField name = new TextField();
		name.setPromptText("Name");
		TextField street = new TextField();
		street.setPromptText("Street");
		TextField floor = new TextField();
		floor.setPromptText("Floor");
		TextField door = new TextField();
		door.setPromptText("Door");
		TextField city = new TextField();
		city.setPromptText("City");
		TextField province = new TextField();
		province.setPromptText("Province");
		TextField postalCode = new TextField();
		province.setPromptText("Postal Code");
		TextField country = new TextField();
		country.setPromptText("Country");

		grid.add(new Label("Name:"), 0, 0);
		grid.add(name, 1, 0);
		grid.add(new Label("(mandatory)"), 2, 0);
		grid.add(new Label("Street:"), 0, 1);
		grid.add(street, 1, 1);
		grid.add(new Label("(mandatory)"), 2, 1);
		grid.add(new Label("Floor:"), 0, 2);
		grid.add(floor, 1, 2);
		grid.add(new Label("Door:"), 0, 3);
		grid.add(door, 1, 3);
		grid.add(new Label("City:"), 0, 4);
		grid.add(city, 1, 4);
		grid.add(new Label("(mandatory)"), 2, 4);
		grid.add(new Label("Province:"), 0, 5);
		grid.add(province, 1, 5);
		grid.add(new Label("Postal Code:"), 0, 6);
		grid.add(postalCode, 1, 6);
		grid.add(new Label("Country:"), 0, 7);
		grid.add(country, 1, 7);
		grid.add(new Label("(mandatory)"), 2, 7);

		Node saveButtonNode = dialog.getDialogPane().lookupButton(saveButtonType);
		saveButtonNode.setDisable(true);

		// TODO el botón save del dialog debería mantenerse deshabilitado hasta que los
		// 4 campos obligatorios tengan texto, estoy en ello :P

		name.textProperty().addListener((observable, oldValue, newValue) -> {
			saveButtonNode.setDisable(mandatoryFields(name, street, city, country));
		});
		street.textProperty().addListener((observable, oldValue, newValue) -> {
			saveButtonNode.setDisable(mandatoryFields(name, street, city, country));
		});
		city.textProperty().addListener((observable, oldValue, newValue) -> {
			saveButtonNode.setDisable(mandatoryFields(name, street, city, country));
		});
		country.textProperty().addListener((observable, oldValue, newValue) -> {
			saveButtonNode.setDisable(mandatoryFields(name, street, city, country));
		});

		dialog.getDialogPane().setContent(grid);

		dialog.setResultConverter(dialogButton -> {
			if (dialogButton == saveButtonType) {
				return new ArrayList<String>(Arrays.asList(name.getText(), street.getText(), floor.getText(),
						door.getText(), city.getText(), province.getText(), postalCode.getText(), country.getText()));
			}
			return null;
		});

		Optional<List<String>> result = dialog.showAndWait();
		if (result.isPresent()) {
			return processAddressDialog(result.get());
		}
		return null;

	}

	boolean mandatoryFields(TextField name, TextField street, TextField city, TextField country) {
		boolean[] results = new boolean[] { name.getText().trim().isEmpty(), street.getText().trim().isEmpty(),
				city.getText().trim().isEmpty(), country.getText().trim().isEmpty() };
		int finalResult = 0;
		for (boolean b : results) {
			if (!b) {
				finalResult++;
			}
		}
		return finalResult != results.length;
	}

	private Address processAddressDialog(List<String> addressData) {
		if (addressData != null) {
			Address address = new Address();
			address.setName(addressData.get(0));
			address.setStreet(addressData.get(1));
			address.setFloor(addressData.get(2));
			address.setDoor(addressData.get(3));
			address.setCity(addressData.get(4));
			address.setProvince(addressData.get(5));
			address.setPostalCode(addressData.get(6));
			address.setCountry(addressData.get(7));
			return address;
		}
		return null;
	}

	private void saveShipment(Shipment shipment, boolean insert) throws Exception {
		final ServiceSaveShipment saveShipment = new ServiceSaveShipment(shipment, insert);

		saveShipment.setOnSucceeded(new EventHandler<WorkerStateEvent>() {

			@Override
			public void handle(WorkerStateEvent t) {


			}
		});

		saveShipment.setOnFailed(new EventHandler<WorkerStateEvent>() {

			@Override
			public void handle(WorkerStateEvent t) {
				Throwable e = t.getSource().getException();

				ControllerMenu.showError(ResourceManager.getInstance().getText("error.formShipment.save.web.service"),
						e.getMessage(), ExceptionUtils.getStackTrace(e));
			}

		});

		saveShipment.start();
	}
}
