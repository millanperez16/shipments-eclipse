package ins.marianao.shipments.fxml;

import cat.institutmarianao.shipmentsws.model.Shipment;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.util.Pair;

public class ControllerShipmentsList {
	@FXML private BorderPane viewShipments;
	
	@FXML private ComboBox<Pair<String,String>> cmbStatus;
	@FXML private TextField txtReceiverSearch;
	@FXML private ComboBox<Pair<String,String>> cmbCategory;
	@FXML private TextField txtCourierSearch;
	
	@FXML private TableView<Shipment> shipmentsTable;
	@FXML private TableColumn<Shipment, Number> colIndex;
	@FXML private TableColumn<Shipment, String> colCategory;
	@FXML private TableColumn<Shipment, String> colNote;
	@FXML private TableColumn<Shipment, Float> colHeight;
	@FXML private TableColumn<Shipment, Float> colWidth;
	@FXML private TableColumn<Shipment, Float> colWeight;
	@FXML private TableColumn<Shipment, Float> colLength;
	@FXML private TableColumn<Shipment, Boolean> colExpress;
	@FXML private TableColumn<Shipment, Boolean> colFragile;
	@FXML private TableColumn<Shipment, Boolean> colDelete;
}
